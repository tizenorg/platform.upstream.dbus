export ELM_SCALE=1.0
export ELM_ENGINE=gl
export ELM_FINGER_SIZE=0
export DBUS_SYSTEM_BUS_ADDRESS=kdbus:path=/dev/kdbus/0-kdbus-system/bus
